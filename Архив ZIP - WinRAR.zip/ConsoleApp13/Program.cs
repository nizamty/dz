﻿using System;
using System.Collections.Generic;


public class Student
{
    public string Name { get; set; }
    public string GroupName { get; set; }
    public int Age { get; set; }
    public double AverageGrade { get; set; }
}

class Program
{
    static void Main()
    {
        List<Student> students = new List<Student>
        {
            new Student { Name = "Иванов Иван", GroupName = "Группа А", Age = 20, AverageGrade = 4.5 },
            new Student { Name = "Петров Петр", GroupName = "Группа А", Age = 21, AverageGrade = 4.2 },
            new Student { Name = "Сидорова Анна", GroupName = "Группа Б", Age = 19, AverageGrade = 4.8 },
            new Student { Name = "Кузнецов Алексей", GroupName = "Группа Б", Age = 22, AverageGrade = 4.1 }
        };

        var groupStatistics = students
            .GroupBy(s => s.GroupName) 
            .Select(g => new
            {
                GroupName = g.Key, 
                StudentCount = g.Count(), 
                AverageAge = g.Average(s => s.Age), 
                MaxAverageGrade = g.Max(s => s.AverageGrade) 
            })
            .OrderBy(g => g.GroupName);
        Console.WriteLine("Отчет по группам студентов:");
        Console.WriteLine("=============================");
        
        foreach (var group in groupStatistics)
        {
            Console.WriteLine($"Группа: {group.GroupName}");
            Console.WriteLine($"  Количество студентов: {group.StudentCount}");
            Console.WriteLine($"  Средний возраст: {group.AverageAge:F1} лет");
            Console.WriteLine($"  Максимальный средний балл: {group.MaxAverageGrade:F2}");
            Console.WriteLine();
        }
    }
}